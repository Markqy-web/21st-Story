// No active JS needed yet
console.log("Script connected");